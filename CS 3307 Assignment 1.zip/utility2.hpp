//
//  utility2.hpp
//  CS 3307 Assignment 1
//
//  Header file for the class utility2
//
//  Created by Mike Lim.
//

#ifndef utility2_hpp
#define utility2_hpp
#include <unistd.h>
#include <stdio.h>
#include <iostream>
#include <string>
#include <sstream>
#include <sys/sysinfo.h>
using namespace std;



#endif /* utility2_hpp */
