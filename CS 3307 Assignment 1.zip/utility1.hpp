//
//  utility1.hpp
//  CS 3307 Assignment 1
//
//  Header file for the class utility1
//
//  Created by Mike Lim.
//

#ifndef utility1_hpp
#define utility1_hpp
#include <unistd.h>
#include <stdio.h>
#include <iostream>
#include <string>
#include <sstream>
#include <sys/sysinfo.h>
using namespace std;



#endif /* utility1_hpp */
