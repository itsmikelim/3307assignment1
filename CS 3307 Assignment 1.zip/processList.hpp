//
//  processList.hpp
//  CS 3307 Assignment 1
//
//  Header file for the class processList
//  Initializes the private and public variables needed
//
//  Created by Mike Lim.
//

#ifndef processList_hpp
#define processList_hpp
#include <unistd.h>
#include <stdio.h>
#include <iostream>
#include <string>
#include <sstream>
#include <sys/types.h>
#include <ifaddrs.h>
#include <vector>
#include <iterator>
#include <iostream>
#include <dirent.h>
#include <cmath>
using namespace std;

class processList
{

public:
    processList();
    
};



#endif /* processList_hpp */
